# LiteraturaChallengeAPI
This project is for a Alura Challenge

<strong>Recomendaciones:</strong>
1. Usar Java Version 21
2. Usar Spring
3. Importar las dependencias de: Spring Data JPA y PostgreSQL Driver
