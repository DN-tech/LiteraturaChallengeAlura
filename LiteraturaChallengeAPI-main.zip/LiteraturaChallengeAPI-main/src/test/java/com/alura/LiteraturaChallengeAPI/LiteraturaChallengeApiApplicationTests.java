package com.alura.LiteraturaChallengeAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiteraturaChallengeApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
